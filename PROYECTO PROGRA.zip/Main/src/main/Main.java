/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import java.util.Scanner;


public class Main {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        String rutaarchivo = System.getProperty("user.dir") + "/Alumnos/Alumnos.txt";
        GestionAlumnos gestionAlumnos = new GestionAlumnos(rutaarchivo);
        Scanner lectura = new Scanner(System.in).useDelimiter("\n");

        int opcionSeleccionada = 0;
        do {
            System.out.println("________Hola amigos, bienvendidos a Guatemala_______\n");
            
            System.out.println("------GESTION DE CONTROL DE DATOS------");
            System.out.println("1. Ingreso de datos personales del Alumno");
            System.out.println("2. Ingreso de los Datos del Curso");
            System.out.println("3. Busqueda del Alumno Carnet");
            System.out.println("4. Busqueda Notas carnet");
            System.out.println("5. Actualizar datos del Alumno ");
            System.out.println("6. Eliminar datos de la Alumno");
            System.out.println("7. Para obtener el total de alumnos y el registro e sus notas ");
            System.out.println("8. PARA SALIR DEL PROGRAMA JAJAJAJA");

            opcionSeleccionada = lectura.nextInt();

            switch (opcionSeleccionada) {
                case 1:
                    gestionAlumnos.ingresarDatosPersonales();
                    break;
                case 2:
                    gestionAlumnos.ingresarDatosCurso();
                    break;
                case 3:
                    gestionAlumnos.buscarAlumnoPorCarnet();
                    break;
                case 4:
                    gestionAlumnos.buscarNotasPorCarnet();
                    break;
                case 5:
                    gestionAlumnos.actualizarDatosAlumno();
                    break;
                case 6:
                    gestionAlumnos.eliminarDatosAlumno();
                    break;
                case 7:
                    gestionAlumnos.Resgistro_de_Alumnos_y_sus_notas();
                    break;
            }
        } while (opcionSeleccionada != 8);    
    }
    
}
