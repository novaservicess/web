/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author franc
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

class GestionAlumnos {

    //Variables Privadas...
    private String rutaarchivo;
    private String nombreapellido;
    private String direccion;
    private String correo;
    private String telefono;
    private String carnet;
    private String idEstudiante;

    public GestionAlumnos(String rutaarchivo) {
        this.rutaarchivo = rutaarchivo;
        // Verificar si el directorio existe, si no, crearlo
        File directorio = new File(System.getProperty("user.dir") + "/Alumnos");
        if (!directorio.exists()) {
            if (directorio.mkdirs()) {
                System.out.println("Directorio creado correctamente.");
            } else {
                System.out.println("Error al crear el directorio.");
                return; // Salir del programa si no se puede crear el directorio
            }
        }
    }

    public void ingresarDatosPersonales() {
        Scanner lectura = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese el carnet del alumno");
        this.carnet = lectura.next();
        System.out.println("Ingrese el nombre y el apellido del alumno");
        this.nombreapellido = lectura.next();
        System.out.println("Ingrese la direccion del alumno del alumno");
        this.direccion = lectura.next();
        System.out.println("Ingrese el correo elctronico del alumno");
        this.correo = lectura.next();
        System.out.println("Ingrese el Telefono del alumno");
        this.telefono = lectura.next();
    }

    public void ingresarDatosCurso() {
        Scanner lectura = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese el carnet del alumno");
        String carnetAlumno = lectura.next();
        System.out.println("Ingrese el NOMBRE CURSO");
        String NOMBREcurso = lectura.next();
        System.out.println("Ingrese el PRIMER_PARCIAL del alumno");
        String PRIMER_PARCIAL = lectura.next();
        System.out.println("Ingrese el SEGUNDO_PARCIAL del alumno");
        String SEGUNDO_PARCIAL = lectura.next();
        System.out.println("Ingrese las ACTIVIDADES alumno");
        String ATIVIDADES = lectura.next();
        System.out.println("Ingrese el EXAMEN_FINAL del alumno");
        String EXAMEN_FINAL = lectura.next();
        System.out.println("Ingrese la NOTA_FINAL del alumno");
        String NOTA_FINAL = lectura.next();

        //Guardado en el archivo
        try (PrintWriter pw = new PrintWriter(new FileWriter(rutaarchivo, true))) {
            pw.println("carnet= " + carnetAlumno);
            pw.println("nombreapellido= " + this.nombreapellido);
            pw.println("direccion= " + this.direccion);
            pw.println("correo= " + this.correo);
            pw.println("telefono= " + this.telefono);
            pw.println("IDESTUDIANTE= " + this.idEstudiante);
            pw.println("NOMBREcurso= " + NOMBREcurso);
            pw.println("PRIMER_PARCIAL= " + PRIMER_PARCIAL);
            pw.println("SEGUNDO_PARCIAL= " + SEGUNDO_PARCIAL);
            pw.println("ATIVIDADES= " + ATIVIDADES);
            pw.println("EXAMEN_FINAL= " + EXAMEN_FINAL);
            pw.println("NOTA_FINAL= " + NOTA_FINAL);
            pw.println("---------------------------------------------------------");
        } catch (IOException e) {
            System.out.println("Error al guardar el registro del alumno: " + e.getMessage());
        }
    }

    public void buscarAlumnoPorCarnet() {
        Scanner lectura = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese el carnet del alumno que desea buscar:");
        String carnetBusqueda = lectura.next();
        try {
            Scanner scanner = new Scanner(new File(rutaarchivo));
            boolean encontrado = false;
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                if (linea.contains("carnet=" + carnetBusqueda)) {
                    System.out.println("Alumno encontrado:");
                    System.out.println(linea);
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                System.out.println("Alumno no encontrado.");
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    public void buscarNotasPorCarnet() {
        Scanner lectura = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese el carnet del alumno del cual desea ver las notas:");
        String carnetBusqueda = lectura.next();
        try {
            Scanner scanner = new Scanner(new File(rutaarchivo));
            boolean encontrado = false;
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                if (linea.contains("carnet=" + carnetBusqueda)) {
                    // Aquí puedes imprimir solo las notas si están en un formato específico
                    System.out.println("Notas del alumno:");
                    System.out.println(linea);
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                System.out.println("Alumno no encontrado.");
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    public void actualizarDatosAlumno() {
        Scanner lectura = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese el carnet del alumno que desea actualizar:");
        String carnetActualizacion = lectura.next();
        try {
            Scanner scanner = new Scanner(new File(rutaarchivo));
            StringBuilder nuevoContenido = new StringBuilder();
            boolean encontrado = false;
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                if (linea.contains("carnet=" + carnetActualizacion)) {
                    System.out.println("Ingrese los nuevos datos personales del alumno:");
                    System.out.println("Nombre y apellido:");
                    String nombreApellidoNuevo = lectura.next();
                    System.out.println("Dirección:");
                    String direccionNueva = lectura.next();
                    System.out.println("Correo electrónico:");
                    String correoNuevo = lectura.next();
                    System.out.println("Teléfono:");
                    String telefonoNuevo = lectura.next();
                    // Construir la nueva línea con los datos actualizados
                    String nuevaLinea = "carnet= " + carnetActualizacion + "\n"
                            + "nombreapellido= " + nombreApellidoNuevo + "\n"
                            + "direccion= " + direccionNueva + "\n"
                            + "correo= " + correoNuevo + "\n"
                            + "telefono= " + telefonoNuevo + "\n"
                            + "---------------------------------------------------------\n";
                    nuevoContenido.append(nuevaLinea);
                    encontrado = true;
                } else {
                    nuevoContenido.append(linea).append("\n");
                }
            }
            scanner.close();
            if (!encontrado) {
                System.out.println("Alumno no encontrado.");
            } else {
                // Escribir el nuevo contenido en el archivo
                FileWriter writer = new FileWriter(rutaarchivo);
                writer.write(nuevoContenido.toString());
                writer.close();
                System.out.println("Datos actualizados exitosamente.");
            }
        } catch (IOException e) {
            System.out.println("Error al actualizar los datos: " + e.getMessage());
        }
    }

    public void eliminarDatosAlumno() {
        Scanner lectura = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese el carnet del alumno que desea eliminar:");
        String carnetEliminar = lectura.next();
        try {
            StringBuilder nuevoContenido = new StringBuilder();
            boolean encontrado = false;
            try (Scanner scanner = new Scanner(new File(rutaarchivo))) {
                while (scanner.hasNextLine()) {
                    String linea = scanner.nextLine();
                    // Verificar si la línea contiene el carnet a eliminar
                    if (linea.contains("carnet=" + carnetEliminar)) {
                        // Eliminar todas las líneas correspondientes al alumno
                        System.out.println("Alumno eliminado:");
                        System.out.println(linea);
                        encontrado = true;
                        // Saltar las siguientes líneas hasta llegar a la siguiente sección de un alumno
                        while (scanner.hasNextLine() && !linea.contains("---------------------------------------------------------")) {
                            linea = scanner.nextLine();
                        }
                    } else {
                        nuevoContenido.append(linea).append("\n");
                    }
                }
            }
            if (!encontrado) {
                System.out.println("Alumno no encontrado.");
            } else {
                // Escribir el nuevo contenido en el archivo (sin el alumno eliminado)
                FileWriter writer = new FileWriter(rutaarchivo);
                writer.write(nuevoContenido.toString());
                writer.close();
                System.out.println("Datos del alumno eliminados exitosamente.");
            }
        } catch (IOException e) {
            System.out.println("Error al eliminar los datos del alumno: " + e.getMessage());
        }
    }

    public void Resgistro_de_Alumnos_y_sus_notas() {
        int totalAlumnos = 0;
        try {
            Scanner scanner = new Scanner(new File(rutaarchivo));
            Set<String> carnetesEncontrados = new HashSet<>();
            while (scanner.hasNextLine()) {
                String linea = scanner.nextLine();
                if (linea.contains("carnet=")) {
                    String carnet = linea.split("=")[1];
                    if (!carnetesEncontrados.contains(carnet)) {
                        System.out.println("Carnet: " + carnet);
                        String nombreApellido = scanner.nextLine().split("=")[1];
                        System.out.println("Nombre y Apellido: " + nombreApellido);
                        System.out.println("Notas:");
                        int contadorNotas = 0;
                        while (scanner.hasNextLine() && !linea.contains("---------------------------------------------------------")) {
                            linea = scanner.nextLine();
                            if (linea.contains("PRIMER_PARCIAL=") || linea.contains("SEGUNDO_PARCIAL=") || linea.contains("ATIVIDADES=") || linea.contains("EXAMEN_FINAL=") || linea.contains("NOTA_FINAL=")) {
                                System.out.println(linea);
                                contadorNotas++;
                            }
                        }
                        System.out.println();
                        totalAlumnos++;
                        carnetesEncontrados.add(carnet);
                    }
                }
            }
            scanner.close();
            System.out.println("Total de alumnos registrados: " + totalAlumnos);
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
